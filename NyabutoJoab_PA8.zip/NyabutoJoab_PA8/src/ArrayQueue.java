import java.util.NoSuchElementException;

public class ArrayQueue<E> implements ArrayQueuInterface <E>{
	
	private Object [] data;
	private int front;
	private int rear;
	
	private int manyItems;
	
	//CONSTRUCTORS
	//Default Constructor
	
	public ArrayQueue() {
		final int Size = 5;
		this.data =	new Object [Size];
		this.manyItems = 0;
	}
	public ArrayQueue(E Size) {
		this.data =	new Object [(Integer) Size];
		this.manyItems = 0;
	}

    public void enqueue(E item) {
        // Check if the Array is full.
        if (this.manyItems == this.data.length) {
            increaseCapacity((this.manyItems * 2) + 1);
        }
        // Check whether the array is Empty
        if (this.manyItems == 0) {
            this.front = 0;
            this.rear = 0;
        } else {
            this.rear = nextIndex(this.rear);
        }
        this.data[this.rear] = item;
        this.manyItems++;
    }

	@SuppressWarnings("unchecked")
	public E dequeue() {
        E item;
        
        //Check whether the queue is empty
        if(this.manyItems == 0)
        	throw new NoSuchElementException("Queue underflow");
        item = (E)this.data[front];
        
        //point front to the next index
        this.front = nextIndex(this.front);
        this.manyItems--;
        
		return item;
	}

	public int nextIndex(int index) {
        index +=1;
        if( index == this.data.length) {
        	return 0;
        }else {
        	return index;
        }
		
	}

	public boolean isEmpty() {
		
		return this.manyItems==0;
	}

	public int size() {
		return this.manyItems;
	}

	public int getCapacity() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void increaseCapacity(int minCapacity) {
    Object [] biggerArray;
    if( this.data.length >= minCapacity) {
    	return;
    }
    else if( this.front<= this.rear) {
    	
    	// Create biggerArray and copy from data[front] to data[rear]
    	biggerArray = new Object[minCapacity];
    	System.arraycopy(this.data, this.front, biggerArray, this.front, this.manyItems);
    	this.data = biggerArray;
    	
    }
    else {
    	
    	
    	biggerArray = new Object[minCapacity];
    	// Copy items from this.front to the end of the array.
    	System.arraycopy(this.data, this.front, biggerArray, 0,( data.length- this.front));
    	
    	// copy the items from the beginning of this.data array to this.rear.
    	System.arraycopy(this.data, 0, biggerArray, (this.data.length - this.front), (this.rear + 1));
    	
    	
    	// Reset front and rear
    	this.front = 0;
    	this.rear = this.manyItems - 1;
    	
    	this.data = biggerArray;
    }
	}

	public void trimToSize() {
		// TODO Auto-generated method stub
		
	}
	public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("Queue: [");
        int index = this.front;
        for (int i = 0; i < this.manyItems; i++) {
            result.append(this.data[index]);
            if (i < this.manyItems - 1) {
                result.append(", ");
            }
            index = nextIndex(index);
        }
        result.append("]");
        return result.toString();
    }
	@SuppressWarnings("unchecked")
	public E peek() {
		if (isEmpty()) {
            throw new NoSuchElementException("Queue is empty");
        }
        return (E) data[front];
        
	}
	

	}


