
public interface ArrayQueuInterface<E> {
	public void enqueue (E Customer);
	public E dequeue ();
	public int nextIndex (int index);
	public boolean isEmpty();
	public int size ();
	public int getCapacity();
	public void increaseCapacity (int minCapacity);
	public void trimToSize();
	public String toString ();
	public E peek();


}
