/**
 * Description: This program simulates cashier lines at a grocery store, where customers enter randomly, join the shortest line, and can leave or switch lines based on certain conditions,
 *              utilizing an array-based queue.
 * @author	Joab Nyabuto
 * @contact	joab.nyabuto@century.edu
 * @since	03/24/2024
 *          
 * Institution:	Century College
 * 
 * Professor:	Mathew Nyamagwa
 * 
 * 
 */
import java.util.Random;

public class Driver {
    public static void main(String[] args) {
        int numCashierLines = 5;
        ArrayQueue<Customer>[] cashierLines = new ArrayQueue[numCashierLines];

        // Initialize cashier lines
        for (int i = 0; i < numCashierLines; i++) {
            cashierLines[i] = new ArrayQueue<>();
        }

        int currentTime = 0;
        int totalCustomersServed = 0;
        int maxTime = 30; // Maximum simulation time
        int maxLineLength = 5; // Maximum length of a line
        int maxWaitTime = 10; // Maximum time a customer waits before leaving
        int checkInterval = 5; // Time interval for checking shorter lines
        Random rand = new Random();

        while (currentTime < maxTime) {
            // Customer arrival
            if (Math.random() < 0.5) { // 50% chance of customer arrival
                Customer newCustomer = new Customer(currentTime);
                int chosenLine = findShortestLine(cashierLines);
                
                // Avoid the line if it's at maximum length
                if (cashierLines[chosenLine].size() >= maxLineLength) {
                    System.out.println("Customer avoided line " + (chosenLine + 1));
                    continue;
                }

                cashierLines[chosenLine].enqueue(newCustomer);
                totalCustomersServed++;
            }

            // Customer departure
            for (int i = 0; i < numCashierLines; i++) {
                if (!cashierLines[i].isEmpty()) {
                    Customer customer = cashierLines[i].peek();
                    int waitTime = currentTime - customer.arrivalTime;
                    
                    // Leave the line if wait time exceeds maximum
                    if (waitTime >= maxWaitTime) {
                        cashierLines[i].dequeue();
                        System.out.println("Customer left line " + (i + 1) + " after waiting too long");
                        continue;
                    }
                    
                    // Check for shorter lines at specified intervals
                    if (currentTime % checkInterval == 0) {
                        int shortestLineIndex = findShortestLine(cashierLines);
                        if (shortestLineIndex != i && cashierLines[shortestLineIndex].size() < cashierLines[i].size()) {
                            // Switch to the shorter line
                            Customer switchedCustomer = cashierLines[i].dequeue();
                            System.out.println("Customer switched from line " + (i + 1) + " to line " + (shortestLineIndex + 1));
                            cashierLines[shortestLineIndex].enqueue(switchedCustomer);
                        }
                    }
                }
            }

            currentTime++;
        }

        // Display results
        for (int i = 0; i < numCashierLines; i++) {
            System.out.println("Line " + (i + 1) + ": " + cashierLines[i].toString());
        }
        System.out.println("Total customers served: " + totalCustomersServed);
    }

    // Helper method to find the shortest line
    private static int findShortestLine(ArrayQueue<Customer>[] cashierLines) {
        int shortestLineIndex = 0;
        int shortestLineLength = Integer.MAX_VALUE;
        for (int i = 0; i < cashierLines.length; i++) {
            if (cashierLines[i].size() < shortestLineLength) {
                shortestLineLength = cashierLines[i].size();
                shortestLineIndex = i;
            }
        }
        return shortestLineIndex;
    }
    
}
class Customer {
    int arrivalTime;

    public Customer(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }
}